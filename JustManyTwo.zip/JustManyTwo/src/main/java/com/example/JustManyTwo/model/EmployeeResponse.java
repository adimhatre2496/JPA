package com.example.JustManyTwo.model;

import lombok.*;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeResponse
    {
        private Long id;

    }
