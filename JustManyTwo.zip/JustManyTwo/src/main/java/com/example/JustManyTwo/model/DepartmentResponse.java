package com.example.JustManyTwo.model;

import lombok.*;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class DepartmentResponse
    {
        private Long id;

    }
