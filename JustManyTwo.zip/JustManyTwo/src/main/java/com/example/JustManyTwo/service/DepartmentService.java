package com.example.JustManyTwo.service;

import com.example.JustManyTwo.entity.DepartmentEntity;
import com.example.JustManyTwo.model.Department;
import com.example.JustManyTwo.model.DepartmentResponse;
import com.example.JustManyTwo.repository.DepartmentRepository;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Log4j2
public class DepartmentService {
 /*   @Autowired
    private DepartmentRepository departmentRepository;

*//*    public DepartmentResponse updateByName(String name, Department department)
    {
        DepartmentEntity departmentEntity=

    }*//*

*//*    public void findByName(String deptName)
    {
        DepartmentEntity departmentEntity=departmentRepository.findByName(deptName);
        log.info("Done");


    }*/
}
