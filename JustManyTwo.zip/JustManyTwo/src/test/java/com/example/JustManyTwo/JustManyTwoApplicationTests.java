package com.example.JustManyTwo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JustManyTwoApplicationTests {

	@Test
	void contextLoads() {
	}

}
